
/**
* The purpose for this Assignment is to create an inventory or fruits,
* Vegetables and Preserve. You'll be able to buy or sell items. We had to
* change our array to an array list. This assignment teaches us to
* learn how to use super classes and sub-classes. Pass scanners and food
* types through a pararmeter. We add a new search, read, and save method.
*
*
* @author  Patrick Johnson john1261
* @version 1.0
* @since   2020-07-19
*/
import java.util.Formatter;
import java.util.Scanner;


public class Vegetable extends FoodItem {
	InventoryItem inventoryItem = new InventoryItem();
	/**
	 * 
	 */
	protected String farmName;

	/**
	 * Default Constructor
	 */
	public Vegetable() {
		super();
		farmName = "";
	}

	@Override
	public boolean addItem(Scanner scanner, boolean fromFile) {
		if (!fromFile) {
			if (super.addItem(scanner, fromFile)) {
				System.out.print("Enter the name of the farm supplier: ");
				farmName = scanner.next();
			
				inventoryItem.addItem(scanner); 
				return true;
			}
		} else {
			// adding from a file
			farmName = scanner.nextLine();
		}
		return true;
	}

	@Override
	public String toString() {
		return super.toString() + " farm supplier: " + farmName + inventoryItem.toString();
	}


}