
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Queue;
import java.util.Scanner;

public class InventoryItem {
	protected int itemQuantityInStock ;// itemQuantityInStock int variable
	protected FoodItem item;
	private Queue<LocalDate>expiries ;
	private int itemCode;
	public InventoryItem() {
		
	}
	/**
	 * Reads from the Scanner object passed in and fills the data member fields of
	 * the class with valid data.
	 * 
	 * @param scanner - Scanner to use for input
	 * @return <code>true</code> if all data members were successfully populated,
	 *         <code>false</code> otherwise
	 */
	public boolean addItem(Scanner scanner) {
		boolean valid = false;
		while (!valid) {
		System.out.print("Enter the quantity for the item: ");
		if (scanner.hasNextInt()) {
			itemQuantityInStock = scanner.nextInt();
			if (itemQuantityInStock < 0) {
				valid = false;
				System.out.println("Invalid input");
				itemQuantityInStock = 0;
			} else
				valid = true;
		} else {
			System.out.println("Invalid input");
			scanner.next();
			valid = false;
		}
	}
		valid = false;
		while (!valid) {
			System.out.print("Enter the expiry date of the item (yyyy-mm-dd or none): ");
			if (scanner.hasNext()) {
				String date;
				SimpleDateFormat df = new SimpleDateFormat("yyyy-mm-dd");
				valid = true;
				date = scanner.next();
				try {
				Date testDate = df.parse(date);
				}catch(ParseException e) {
					System.out.println("Invalid date");
					valid = false;
				} 		
			}
		}
	
		return true;
	}


	/**
	 * Reads a valid itemCode from the Scanner object and returns true/false if
	 * successful
	 * 
	 * @param scanner - Scanner to use for input
	 * @return <code>true</code> if code was populated, <code>false</code> otherwise
	 */
	public boolean inputCode(Scanner scanner, boolean fromFile) {
		boolean validInput = false;
		
		while (!validInput) {

			System.out.print("Enter the code for the item: ");
			if (scanner.hasNextInt()) {
				itemCode = scanner.nextInt();
				validInput = true;
			} else {
				System.out.println("Invalid code");
				// Clear the invalid input
				scanner.next();
			}
		}

		return validInput;
	}
	// getter for item code
	public int getitemCode() {
		return itemCode;

	}
	public void printExpirySummary() {
		
	}
	public void removeExpiredItems(LocalDate today) {
		
	}
	
	public boolean updateQuantity(Scanner scanner,int amount) {
		// If you are removing stock, then check that we have enough stock
		if (amount < 0 && itemQuantityInStock < (amount * -1)) {
			return false;
		}
		itemQuantityInStock += amount;
		
		return true;
	}

	
	public String toString() {
		return " qty "+ itemQuantityInStock ;

	}



}
