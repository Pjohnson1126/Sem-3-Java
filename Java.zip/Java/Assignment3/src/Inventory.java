
/**
* The purpose for this Assignment is to create an inventory or fruits,
* Vegetables and Preserve. You'll be able to buy or sell items. We had to
* change our array to an array list. This assignment teaches us to
* learn how to use super classes and sub-classes. Pass scanners and food
* types through a pararmeter. We add a new search, read, and save method.
*
*
* @author  Patrick Johnson john1261
* @version 1.0
* @since   2020-07-19
*/
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Inventory {
	/**
	 * array List of FoodItems that represents our inventory
	 */
	// private FoodItem[] inventory;
	ArrayList<FoodItem> inventory = new ArrayList<FoodItem>();

	/**
	 * Number of items that a user has entered
	 */
	private int numItems;

	/**
	 * Default Constructor
	 */
	public Inventory() {
		// ArrayList<String> inventory = new ArrayList<String>();
		// inventory = new FoodItem[20];
	}

	/**
	 * Reads from the Scanner object passed in and fills the data member fields of
	 * the class with valid data.
	 * 
	 * @param scanner - Scanner to use for input
	 * @return <code>true</code> if all data members were successfully populated,
	 *         <code>false</code> otherwise
	 */
	public boolean addItem(Scanner scanner, boolean fromFile) {
		// adding to the array list not from a file
		if (!fromFile) {
			if (numItems == 20) {
				System.out.println("Inventory full");
				return false;
			}
			boolean valid = false;
			FoodItem item = new FoodItem();
			while (!valid) {
				System.out.print("Do you wish to add a fruit(f), vegetable(v) or a preserve(p)? ");
				if (scanner.hasNext(Pattern.compile("[fFvVpP]"))) {
					String choice = scanner.next();
					switch (choice.toLowerCase()) {
					case "f":// calls fruit
						item = new Fruit();
						break;
					case "v":// call vegatable
						item = new Vegetable();
						break;
					case "p":// calls preserve
						item = new Preserve();
						break;
					default: // Should not get here.
						item = new FoodItem();
						break;
					}
					valid = true;
				} else {
					System.out.println("Invalid entry");
					scanner.next();
					valid = false;
				}
			}
			if (item.inputCode(scanner, fromFile)) {
				if (alreadyExists(item) < 0) {
					if (item.addItem(scanner, fromFile)) {
						inventory.add(item);// add item to array lsit
						numItems++;
						// sorting the array list by the itemCode
						for (int i = 0; i < inventory.size(); i++) {
							for (int j = inventory.size() - 1; j > i; j--) {
								if (inventory.get(i).getitemCode() > inventory.get(j).getitemCode()) {
									FoodItem temp = inventory.get(i);
									inventory.set(i, inventory.get(j));
									inventory.set(j, temp);

								}
							}
						}
						return true;
					}
					return false;
					// if the itemCode is in the inventory array list, error message will display
				} else {
					System.out.println("Item code already exists");
					return false;
				}
			}

			// return true;
		}
		return true;
	}

	/**
	 * Search for a food item and see if it is already stored in the inventory
	 * 
	 * @param item - FoodItem to look for
	 * @return - The index of item if it is found, -1 otherwise
	 */
	public int alreadyExists(FoodItem item) {
		for (int i = 0; i < numItems; i++) {

			if (inventory.get(i).isEqual(item))
				return i;
		}
		return -1;
	}

	/**
	 * Update the quanity stored in the food item
	 * 
	 * @param scanner   - Input device to use
	 * @param buyOrSell - If we are to add to quantity (<code>true</code>) or remove
	 *                  (<code>false</code>)
	 * @return
	 */
	public boolean updateQuantity(Scanner scanner, boolean buyOrSell) {
		// If there are no items then we can't update, return
		if (numItems == 0)
			return false;

		FoodItem temp = new FoodItem();
		temp.inputCode(scanner, buyOrSell);
		int index = alreadyExists(temp);
		if (index != -1) {
			String buySell = buyOrSell ? "buy" : "sell";
			System.out.print("Enter valid quantity to " + buySell + ": ");
			if (scanner.hasNextInt()) {
				int amount = scanner.nextInt();
				if (amount > 0) {
					return inventory.get(index).updateItem(buyOrSell ? amount : amount * -1);
				} else {
					System.out.println("Invalid quantity...");
				}
			} else {
				System.out.println("Invalid quantity...");
			}
		}
		return false;
	}

	// displays all the inventory data.
	public String toString() {
		String returnString = "Inventory:\n";
		for (int i = 0; i < numItems; i++)
			returnString += inventory.get(i).toString() + "\n";
		return returnString;
	}

	// this method searchs the array and displays the line you want.
	// Uses comparable to see if the itemCode is in the array list.
	public void searchForItem(Scanner scanner) {
		int search;
		int found = 0;
		System.out.println("Enter the code for the item: ");
		search = scanner.nextInt();// scans the code you want.
		FoodItem food = new FoodItem();
		FoodItem food1 = new FoodItem();
		food1.itemCode = search;
		// search though the array and using the comparable method to see if the two
		// itemCodes are the same
		for (int i = 0; i < numItems; i++) {
			food = inventory.get(i);
			if (food1.compareTo(food) == 0) {
				// if they are the see, that inventory line displays
				System.out.println(inventory.get(i).toString());
				found = 1;
				break;
			}

		}
		// if its not found an error message will display
		if (found == 0) {
			System.out.println("Code not found in inventory...");
		}

	}

}
