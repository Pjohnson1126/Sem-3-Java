
/**
* The purpose for this Assignment is to create an inventory or fruits,
* Vegetables and Preserve. You'll be able to buy or sell items. We had to
* change our array to an array list. This assignment teaches us to
* learn how to use super classes and sub-classes. Pass scanners and food
* types through a pararmeter. We add a new search, read, and save method.
*
*
* @author  Patrick Johnson john1261
* @version 1.0
* @since   2020-07-19
*/
import java.util.Formatter;
import java.util.Scanner;

public class Preserve extends FoodItem {
	InventoryItem inventoryItem = new InventoryItem();
	/**
	 * 
	 */
	protected int jarSize;

	/**
	 * Default Constructor
	 */
	public Preserve() {
		super();
		jarSize = 0;
	}

	@Override
	public boolean addItem(Scanner scanner, boolean fromFile) {
		boolean valid = false;
		if (!fromFile) {
			if (super.addItem(scanner, fromFile)) {
				// Input quantity
				while (!valid) {
					System.out.print("Enter the size of the jar in millilitres: ");
					if (scanner.hasNextInt()) {
						jarSize = scanner.nextInt();
						if (jarSize < 0) {
							valid = false;
							System.out.println("Invalid input");
							jarSize = 0;
						} else
							valid = true;
					} else {
						System.out.println("Invalid input");
						scanner.next();
						valid = false;
					}
				}
			}
			
			inventoryItem.addItem(scanner); 
		} else {
			// add from file
			jarSize = Integer.parseInt(scanner.nextLine());
			return true;
		}
		return true;
	}

	@Override
	public String toString() {
		return super.toString() + " size: " + jarSize + "mL" + inventoryItem.toString();
	}



}