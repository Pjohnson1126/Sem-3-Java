/**
* The purpose for this Assignment is to create an inventory or fruits,
* Vegetables and Preserve. You'll be able to buy or sell items. We had to
* change our array to an array list. This assignment teaches us to
* learn how to use super classes and sub-classes. Pass scanners and food
* types through a pararmeter. We add a new search, read, and save method.
*
*
* @author  Patrick Johnson john1261
* @version 1.0
* @since   2020-07-19
*/
import java.io.IOException;
import java.util.Formatter;
import java.util.Scanner;

//super class
public class FoodItem implements Comparable<FoodItem> {

	protected int itemCode;// ItemCode int variable
	protected String itemName; // itemName String variable
	protected float itemPrice;// itemPrice float variable
	protected float itemCost;// itemCase float variable
	protected int itemQuantityInStock;// itemQuantityInStock int variable
	InventoryItem inventoryItem = new InventoryItem();

	/**
	 * Default Constructor
	 */
	public FoodItem() {
		itemCode = 0;
		itemName = "";
		itemPrice = 0.0f;
		itemCost = 0.0f;
		
	}

	/**
	 * Reads from the Scanner object passed in and fills the data member fields of
	 * the class with valid data.
	 * 
	 * @param scanner - Scanner to use for input
	 * @return <code>true</code> if all data members were successfully populated,
	 *         <code>false</code> otherwise
	 */
	public boolean addItem(Scanner scanner, boolean fromFile) {
		boolean valid = false;
		// adding not form the file
		if (!fromFile) {
			System.out.print("Enter the name for the item: ");
			itemName = scanner.next();
			// Input quantity
			/*while (!valid) {
				System.out.print("Enter the quantity for the item: ");
				if (scanner.hasNextInt()) {
					itemQuantityInStock = scanner.nextInt();
					if (itemQuantityInStock < 0) {
						valid = false;
						System.out.println("Invalid input");
						itemQuantityInStock = 0;
					} else
						valid = true;
				} else {
					System.out.println("Invalid input");
					scanner.next();
					valid = false;
				}
			}*/

			// Input the cost
			valid = false;
			while (!valid) {
				System.out.print("Enter the cost of the item: ");
				if (scanner.hasNextFloat()) {
					itemCost = scanner.nextFloat();
					if (itemCost < 0) {
						valid = false;
						System.out.println("Invalid input");
						itemCost = 0;
					} else
						valid = true;
				} else {
					System.out.println("Invalid input");
					scanner.next();
					valid = false;
				}
			}

			// Input the price
			valid = false;
			while (!valid) {
				System.out.print("Enter the sales price of the item: ");
				if (scanner.hasNextFloat()) {
					itemPrice = scanner.nextFloat();
					if (itemPrice < 0) {
						valid = false;
						System.out.println("Invalid input");
						itemPrice = 0;
					} else
						valid = true;
				} else {
					System.out.println("Invalid input");
					scanner.next();
					valid = false;
				}
			}
		
		}
		return true;
	}

	/**
	 * Reads a valid itemCode from the Scanner object and returns true/false if
	 * successful
	 * 
	 * @param scanner - Scanner to use for input
	 * @return <code>true</code> if code was populated, <code>false</code> otherwise
	 */
	public boolean inputCode(Scanner scanner, boolean fromFile) {
		boolean validInput = false;

		while (!validInput) {

			System.out.print("Enter the code for the item: ");
			if (scanner.hasNextInt()) {
				itemCode = scanner.nextInt();
				validInput = true;
			} else {
				System.out.println("Invalid code");
				// Clear the invalid input
				scanner.next();
			}
		}

		return validInput;
	}

	/**
	 * Compares this object's item code with the one passed in
	 * 
	 * @param item - object to compare with
	 * @return <code>true</code> if the itemCode of the object being acted on and
	 *         the item object parameter are the same value, <code>false</code>
	 *         otherwise
	 */
	public boolean isEqual(FoodItem item) {
		return itemCode == item.itemCode;
	}

	/**
	 * Updates the quantity field by amount (note amount could be positive or
	 * negative)
	 * 
	 * @param amount - what to update by, either can be positive or negative
	 * @return Method returns <code>true</code> if successful, otherwise returns
	 *         <code>false</code>
	 */
	public boolean updateItem(int amount) {
		// If you are removing stock, then check that we have enough stock
		if (amount < 0 && itemQuantityInStock < (amount * -1)) {
			return false;
		}
		itemQuantityInStock += amount;
		
	
		return true;
	}

	// to format output when reading inventory to the file
	public void outputItem(Formatter writer) {
		writer.format(itemCode + "\n" + itemName + "\n " + itemQuantityInStock + "\n" + String.format("%.2f", itemPrice)
				+ "\n" + String.format("%.2f", itemCost));

	}

	@Override
	// displays toString in inventory, displays all data members
	public String toString() {
		return "Item: " + itemCode + " " + itemName + " " + " price: $"
				+ String.format("%.2f", itemPrice) + " cost: $" + String.format("%.2f", itemCost);

	}

	// getter for item code
	public int getitemCode() {
		return itemCode;

	}

	// comparable method to see if an itemCode is in the array list
	public int compareTo(FoodItem f1) {
		return Integer.compare(this.itemCode, f1.itemCode);
	}

}
